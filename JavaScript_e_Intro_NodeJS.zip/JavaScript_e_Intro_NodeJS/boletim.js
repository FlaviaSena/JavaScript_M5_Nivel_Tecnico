const media = require('./media.js')
const notasPorBimestre = [7, 9, 4, 9]
media.calculaMedia(notasPorBimestre)
console.log(media.calculaMedia(notasPorBimestre));