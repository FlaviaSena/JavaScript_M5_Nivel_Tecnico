/*function mae() {
    this.nome = "Função mãe";
    function filha() {
    document.write("Rodando função filha");
    document.write(`Nome do escopo da mãe: ${this.nome}`);
    }
    filha();
   }
   
   mae();
   try {
    filha();
   } catch (error) {
    console.log("Essa função não existe no escopo global!")
   }*/



   
   //Decrementa em 10 saldos que estejam abaixo de 0
const saldos = [120.54, 0, 5.29, -72, 13, -25.3];
const saldosDecrementados [];
for (let i=0; i<saldos.length; i++) {
 if (saldos[i] < 0) {
 saldosDecrementados .push(saldos[i]-10);
 } else {
 saldosDecrementados .push(saldos[i]);
 }
}