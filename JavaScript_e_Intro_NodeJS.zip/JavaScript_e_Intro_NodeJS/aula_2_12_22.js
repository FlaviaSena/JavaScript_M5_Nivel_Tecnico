const pessoas = [
    {nome: "Julio", idade: 22},
    {nome: "Laura", idade: 35},
    {nome: "Manu", idade: 15},
    {nome: "Jefferson", idade: 17}
   ];
   const podemBeber = pessoas.filter( pes => pes.idade >= 18? true :
   false);
   console.log(pessoas);