/*const frutas = ['Banana', 'Uva']
const [fruta1, fruta2] = frutas
console.log('frutas');
console.log('frutas1');
console.log('frutas2');
*/

/*const objComplicado = {
    arrayProp: [ "Resilia",{ ramo: "Educação" }]
    
   }
   const { arrayProp: [primeiro, segundo ] } = objComplicado
   console.log(objComplicado);
   console.log(primeiro);
   console.log(segundo);
   */

