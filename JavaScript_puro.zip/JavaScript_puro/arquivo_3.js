function saudacao(){
alert("Olá mundo");
alert("Como vai meu amigo Raphael tudo bom me conta as novidades");
}

function lerNome(){
var eu = prompt("olá qual o seu nome minha querida");
alert("Olá amiga " + eu);
}
function calcular(){
    var q = document.getElementById("quantidade").value;
    var v = document.getElementById("valor").value;

    var total = q * v;
     alert( "O valor multiplicado é de"  = total);
}