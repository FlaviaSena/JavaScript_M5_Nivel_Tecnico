var valor1 =prompt("qual é o valor? ");
var valor2 =prompt("qual é a quantidade de pessoas?");
var total = valor1 / valor2;
alert("O valor total que cada um deve pagar é de  " + "R$" + total );
prompt("Você agora tem o seu resultado");