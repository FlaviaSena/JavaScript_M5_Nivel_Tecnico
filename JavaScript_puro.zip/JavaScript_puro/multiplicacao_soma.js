var dias =prompt("Qual é o total de dias em que você vai precisar estar em viagem?");
var horas =prompt("Por favor me informe as horas que você levou de viagem?");
var total = ((dias * 24) + horas *1);
alert("Você está viajando a exatamente " + total + "Horas");